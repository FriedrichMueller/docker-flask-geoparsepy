--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = reveal, pg_catalog;

DROP INDEX reveal.au_nz_places_poly_gist_index;
DROP INDEX reveal.au_nz_places_point_gist_index;
DROP INDEX reveal.au_nz_places_line_gist_index;
DROP INDEX reveal.au_nz_places_admin_gist_index;
ALTER TABLE ONLY reveal.au_nz_places_poly DROP CONSTRAINT au_nz_places_poly_pkey;
ALTER TABLE ONLY reveal.au_nz_places_point DROP CONSTRAINT au_nz_places_point_pkey;
ALTER TABLE ONLY reveal.au_nz_places_line DROP CONSTRAINT au_nz_places_line_pkey;
ALTER TABLE ONLY reveal.au_nz_places_admin DROP CONSTRAINT au_nz_places_admin_pkey;
ALTER TABLE reveal.au_nz_places_poly ALTER COLUMN loc_id DROP DEFAULT;
ALTER TABLE reveal.au_nz_places_point ALTER COLUMN loc_id DROP DEFAULT;
ALTER TABLE reveal.au_nz_places_line ALTER COLUMN loc_id DROP DEFAULT;
ALTER TABLE reveal.au_nz_places_admin ALTER COLUMN loc_id DROP DEFAULT;
DROP SEQUENCE reveal.au_nz_places_poly_loc_id_seq;
DROP TABLE reveal.au_nz_places_poly;
DROP SEQUENCE reveal.au_nz_places_point_loc_id_seq;
DROP TABLE reveal.au_nz_places_point;
DROP SEQUENCE reveal.au_nz_places_line_loc_id_seq;
DROP TABLE reveal.au_nz_places_line;
DROP SEQUENCE reveal.au_nz_places_admin_loc_id_seq;
DROP TABLE reveal.au_nz_places_admin;
SET search_path = reveal, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: au_nz_places_admin; Type: TABLE; Schema: reveal; Owner: postgres; Tablespace: 
--

CREATE TABLE au_nz_places_admin (
    loc_id integer NOT NULL,
    name text,
    osm_id_set bigint[],
    admin_regions bigint[],
    geom public.geometry(Geometry,4326),
    tags public.hstore
);


ALTER TABLE reveal.au_nz_places_admin OWNER TO postgres;

--
-- Name: au_nz_places_admin_loc_id_seq; Type: SEQUENCE; Schema: reveal; Owner: postgres
--

CREATE SEQUENCE au_nz_places_admin_loc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reveal.au_nz_places_admin_loc_id_seq OWNER TO postgres;

--
-- Name: au_nz_places_admin_loc_id_seq; Type: SEQUENCE OWNED BY; Schema: reveal; Owner: postgres
--

ALTER SEQUENCE au_nz_places_admin_loc_id_seq OWNED BY au_nz_places_admin.loc_id;


--
-- Name: au_nz_places_line; Type: TABLE; Schema: reveal; Owner: postgres; Tablespace: 
--

CREATE TABLE au_nz_places_line (
    loc_id integer NOT NULL,
    name text,
    osm_id_set bigint[],
    admin_regions bigint[],
    geom public.geometry(Geometry,4326),
    tags public.hstore
);


ALTER TABLE reveal.au_nz_places_line OWNER TO postgres;

--
-- Name: au_nz_places_line_loc_id_seq; Type: SEQUENCE; Schema: reveal; Owner: postgres
--

CREATE SEQUENCE au_nz_places_line_loc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reveal.au_nz_places_line_loc_id_seq OWNER TO postgres;

--
-- Name: au_nz_places_line_loc_id_seq; Type: SEQUENCE OWNED BY; Schema: reveal; Owner: postgres
--

ALTER SEQUENCE au_nz_places_line_loc_id_seq OWNED BY au_nz_places_line.loc_id;


--
-- Name: au_nz_places_point; Type: TABLE; Schema: reveal; Owner: postgres; Tablespace: 
--

CREATE TABLE au_nz_places_point (
    loc_id integer NOT NULL,
    name text,
    osm_id_set bigint[],
    admin_regions bigint[],
    geom public.geometry(Geometry,4326),
    tags public.hstore
);


ALTER TABLE reveal.au_nz_places_point OWNER TO postgres;

--
-- Name: au_nz_places_point_loc_id_seq; Type: SEQUENCE; Schema: reveal; Owner: postgres
--

CREATE SEQUENCE au_nz_places_point_loc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reveal.au_nz_places_point_loc_id_seq OWNER TO postgres;

--
-- Name: au_nz_places_point_loc_id_seq; Type: SEQUENCE OWNED BY; Schema: reveal; Owner: postgres
--

ALTER SEQUENCE au_nz_places_point_loc_id_seq OWNED BY au_nz_places_point.loc_id;


--
-- Name: au_nz_places_poly; Type: TABLE; Schema: reveal; Owner: postgres; Tablespace: 
--

CREATE TABLE au_nz_places_poly (
    loc_id integer NOT NULL,
    name text,
    osm_id_set bigint[],
    admin_regions bigint[],
    geom public.geometry(Geometry,4326),
    tags public.hstore
);


ALTER TABLE reveal.au_nz_places_poly OWNER TO postgres;

--
-- Name: au_nz_places_poly_loc_id_seq; Type: SEQUENCE; Schema: reveal; Owner: postgres
--

CREATE SEQUENCE au_nz_places_poly_loc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reveal.au_nz_places_poly_loc_id_seq OWNER TO postgres;

--
-- Name: au_nz_places_poly_loc_id_seq; Type: SEQUENCE OWNED BY; Schema: reveal; Owner: postgres
--

ALTER SEQUENCE au_nz_places_poly_loc_id_seq OWNED BY au_nz_places_poly.loc_id;


--
-- Name: loc_id; Type: DEFAULT; Schema: reveal; Owner: postgres
--

ALTER TABLE ONLY au_nz_places_admin ALTER COLUMN loc_id SET DEFAULT nextval('au_nz_places_admin_loc_id_seq'::regclass);


--
-- Name: loc_id; Type: DEFAULT; Schema: reveal; Owner: postgres
--

ALTER TABLE ONLY au_nz_places_line ALTER COLUMN loc_id SET DEFAULT nextval('au_nz_places_line_loc_id_seq'::regclass);


--
-- Name: loc_id; Type: DEFAULT; Schema: reveal; Owner: postgres
--

ALTER TABLE ONLY au_nz_places_point ALTER COLUMN loc_id SET DEFAULT nextval('au_nz_places_point_loc_id_seq'::regclass);


--
-- Name: loc_id; Type: DEFAULT; Schema: reveal; Owner: postgres
--

ALTER TABLE ONLY au_nz_places_poly ALTER COLUMN loc_id SET DEFAULT nextval('au_nz_places_poly_loc_id_seq'::regclass);


--
-- Data for Name: au_nz_places_admin; Type: TABLE DATA; Schema: reveal; Owner: postgres
--

COPY au_nz_places_admin (loc_id, name, osm_id_set, admin_regions, geom, tags) FROM stdin;
\.
COPY au_nz_places_admin (loc_id, name, osm_id_set, admin_regions, geom, tags) FROM '$$PATH$$/4254.dat';

--
-- Name: au_nz_places_admin_loc_id_seq; Type: SEQUENCE SET; Schema: reveal; Owner: postgres
--

SELECT pg_catalog.setval('au_nz_places_admin_loc_id_seq', 1, false);


--
-- Data for Name: au_nz_places_line; Type: TABLE DATA; Schema: reveal; Owner: postgres
--

COPY au_nz_places_line (loc_id, name, osm_id_set, admin_regions, geom, tags) FROM stdin;
\.
COPY au_nz_places_line (loc_id, name, osm_id_set, admin_regions, geom, tags) FROM '$$PATH$$/4250.dat';

--
-- Name: au_nz_places_line_loc_id_seq; Type: SEQUENCE SET; Schema: reveal; Owner: postgres
--

SELECT pg_catalog.setval('au_nz_places_line_loc_id_seq', 1, false);


--
-- Data for Name: au_nz_places_point; Type: TABLE DATA; Schema: reveal; Owner: postgres
--

COPY au_nz_places_point (loc_id, name, osm_id_set, admin_regions, geom, tags) FROM stdin;
\.
COPY au_nz_places_point (loc_id, name, osm_id_set, admin_regions, geom, tags) FROM '$$PATH$$/4248.dat';

--
-- Name: au_nz_places_point_loc_id_seq; Type: SEQUENCE SET; Schema: reveal; Owner: postgres
--

SELECT pg_catalog.setval('au_nz_places_point_loc_id_seq', 8363, true);


--
-- Data for Name: au_nz_places_poly; Type: TABLE DATA; Schema: reveal; Owner: postgres
--

COPY au_nz_places_poly (loc_id, name, osm_id_set, admin_regions, geom, tags) FROM stdin;
\.
COPY au_nz_places_poly (loc_id, name, osm_id_set, admin_regions, geom, tags) FROM '$$PATH$$/4252.dat';

--
-- Name: au_nz_places_poly_loc_id_seq; Type: SEQUENCE SET; Schema: reveal; Owner: postgres
--

SELECT pg_catalog.setval('au_nz_places_poly_loc_id_seq', 1, false);


--
-- Name: au_nz_places_admin_pkey; Type: CONSTRAINT; Schema: reveal; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY au_nz_places_admin
    ADD CONSTRAINT au_nz_places_admin_pkey PRIMARY KEY (loc_id);


--
-- Name: au_nz_places_line_pkey; Type: CONSTRAINT; Schema: reveal; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY au_nz_places_line
    ADD CONSTRAINT au_nz_places_line_pkey PRIMARY KEY (loc_id);


--
-- Name: au_nz_places_point_pkey; Type: CONSTRAINT; Schema: reveal; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY au_nz_places_point
    ADD CONSTRAINT au_nz_places_point_pkey PRIMARY KEY (loc_id);


--
-- Name: au_nz_places_poly_pkey; Type: CONSTRAINT; Schema: reveal; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY au_nz_places_poly
    ADD CONSTRAINT au_nz_places_poly_pkey PRIMARY KEY (loc_id);


--
-- Name: au_nz_places_admin_gist_index; Type: INDEX; Schema: reveal; Owner: postgres; Tablespace: 
--

CREATE INDEX au_nz_places_admin_gist_index ON au_nz_places_admin USING gist (geom);


--
-- Name: au_nz_places_line_gist_index; Type: INDEX; Schema: reveal; Owner: postgres; Tablespace: 
--

CREATE INDEX au_nz_places_line_gist_index ON au_nz_places_line USING gist (geom);


--
-- Name: au_nz_places_point_gist_index; Type: INDEX; Schema: reveal; Owner: postgres; Tablespace: 
--

CREATE INDEX au_nz_places_point_gist_index ON au_nz_places_point USING gist (geom);


--
-- Name: au_nz_places_poly_gist_index; Type: INDEX; Schema: reveal; Owner: postgres; Tablespace: 
--

CREATE INDEX au_nz_places_poly_gist_index ON au_nz_places_poly USING gist (geom);


--
-- PostgreSQL database dump complete
--

